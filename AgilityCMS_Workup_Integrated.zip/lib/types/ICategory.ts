export interface ICategory {
	title: string
}