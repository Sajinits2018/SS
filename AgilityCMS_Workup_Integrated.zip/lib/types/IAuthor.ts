export interface IAuthor {
	name: String
}