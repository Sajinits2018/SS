export interface ITag {
	title: String
}